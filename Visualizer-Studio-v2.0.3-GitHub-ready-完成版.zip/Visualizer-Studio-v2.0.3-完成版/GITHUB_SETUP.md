# GitHub登録手順

GitHub Desktopで `bearknuckle/Visualizer-Studio` をCloneしたフォルダに、
このパッケージの中身をコピーしてください。

1. GitHub DesktopでChangesを確認
2. Summaryに `Visualizer Studio v2.0.3 完成版` と入力
3. `Commit to main`
4. `Push origin`
5. GitHubのリポジトリで内容を確認

## 登録するもの
- Visualizer_Studio.py
- versions/v2.0.3/Visualizer_Studio.py
- README.md
- CHANGELOG.md
- .gitignore
- GITHUB_SETUP.md

## 登録しないもの
build / dist / EXEなどの生成物はGitHubのソース管理対象から除外します。
