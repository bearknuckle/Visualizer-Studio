# Visualizer Studio

MP4動画に音楽連動のスペクトラムビジュアライザーを追加して、新しいMP4として書き出すWindows向けPythonツールです。

## Current Version

**v2.0.3 完成版**

### v2.0.3
- スペクトラムバーを60本から40本へ変更
- バー間の隙間を縮小し、バーを太く見えるように調整
- v2.0.2までの安定した動作を維持
- EXE化・起動確認済み

## Features
- MP4動画を読み込み
- 音声を解析してスペクトラムを生成
- 動画下部に音楽連動のバー型ビジュアライザーを表示
- 新しいMP4として書き出し
- 長時間動画に対応

## Repository structure

```text
Visualizer-Studio/
├── README.md
├── CHANGELOG.md
├── .gitignore
├── GITHUB_SETUP.md
├── Visualizer_Studio.py
└── versions/
    └── v2.0.3/
        └── Visualizer_Studio.py
```

## Development
Python 3.14 で開発しています。

実行にはFFmpeg / FFprobeが必要です。
開発環境ではPATHに設定するか、プロジェクト内の `ffmpeg` フォルダに配置してください。

## Version policy
安定版を基準に、変更内容ごとにバージョンを更新します。

- v2.0.2: 約1時間の動画で動作確認済み
- v2.0.3: スペクトラムバーを太く調整した完成版
